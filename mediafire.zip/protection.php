<?php
session_start();

function zcodeGenerateSession($length = 5) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $token = '';
    $maxRandIndex = strlen($characters) - 1;
    for ($i = 0; $i < $length; $i++) {
        $token .= $characters[random_int(0, $maxRandIndex)];
    }
    return $token;
}

function saveSessionToken($token) {
    $_SESSION['secToken'] = $token;
}

function getSessionToken() {
    return $_SESSION['secToken'] ?? null;
}

function validateSessionToken($token) {
    return $token === getSessionToken();
}

if (!isset($_SESSION['userAgent']) || $_SESSION['userAgent'] !== $_SERVER['HTTP_USER_AGENT']) {
    session_regenerate_id(true);
    $_SESSION['userAgent'] = $_SERVER['HTTP_USER_AGENT'];
}

if (!isset($_SESSION['secToken'])) {
    saveSessionToken(zcodeGenerateSession(5));
}

$securityToken = getSessionToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['zcodeToken'])) {
    if (validateSessionToken($_POST['zcodeToken'])) {
        echo "
        <form id='zcodeSub' method='POST' action='index.php?zToken=verified'>
            <input type='hidden' name='sessionToken' value='kingtirzz23nesiareal'>
        </form>
        <script>document.getElementById('zcodeSub').submit();</script>";
        exit();
    } else {
        echo "<script>alert('Token tidak valid!'); window.location='protection.php';</script>";
        exit();
    }
}

$requestId = strtoupper(substr(md5(microtime(true) . rand()), 0, 12));
$rayId = strtoupper(substr(md5($_SERVER['REMOTE_ADDR'] ?? '0'), 0, 16));
$userIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$timestamp = date('Y-m-d H:i:s T');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Security Check - Verifying your connection</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/TirzzNesia/mylibrary@main/verify/verifyfile.css">
    <style></style>
</head>
<body>

<div class="glow-orb g1"></div>
<div class="glow-orb g2"></div>
<div class="glow-orb g3"></div>

<div class="main-wrapper">
    <div class="top-bar">
        <svg class="g-icon" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
            <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v8.5h12.7c-.6 3-2.3 5.5-4.8 7.2v6h7.7c4.5-4.1 7-10.2 7-17.2z"/>
            <path fill="#34A853" d="M24 47c6.5 0 11.9-2.1 15.9-5.8l-7.7-6c-2.1 1.4-4.8 2.3-8.2 2.3-6.3 0-11.6-4.2-13.5-9.9H2.6v6.2C6.5 41.8 14.7 47 24 47z"/>
            <path fill="#FBBC05" d="M10.5 28.6c-.5-1.4-.8-2.9-.8-4.6s.3-3.2.8-4.6v-6.2H2.6C1 16.4 0 20.1 0 24s1 7.6 2.6 10.8l7.9-6.2z"/>
            <path fill="#EA4335" d="M24 9.5c3.5 0 6.7 1.2 9.2 3.6l6.9-6.9C35.9 2.1 30.5 0 24 0 14.7 0 6.5 5.2 2.6 13.2l7.9 6.2C12.4 13.7 17.7 9.5 24 9.5z"/>
        </svg>
        <div class="url-text"><span>Google Secure</span> - protected connection</div>
    </div>

    <div class="card">
        <div id="loadingState">
            <div class="shield-wrap">
                <div class="shield-bg">
                    <svg class="google-g" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
                        <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v8.5h12.7c-.6 3-2.3 5.5-4.8 7.2v6h7.7c4.5-4.1 7-10.2 7-17.2z"/>
                        <path fill="#34A853" d="M24 47c6.5 0 11.9-2.1 15.9-5.8l-7.7-6c-2.1 1.4-4.8 2.3-8.2 2.3-6.3 0-11.6-4.2-13.5-9.9H2.6v6.2C6.5 41.8 14.7 47 24 47z"/>
                        <path fill="#FBBC05" d="M10.5 28.6c-.5-1.4-.8-2.9-.8-4.6s.3-3.2.8-4.6v-6.2H2.6C1 16.4 0 20.1 0 24s1 7.6 2.6 10.8l7.9-6.2z"/>
                        <path fill="#EA4335" d="M24 9.5c3.5 0 6.7 1.2 9.2 3.6l6.9-6.9C35.9 2.1 30.5 0 24 0 14.7 0 6.5 5.2 2.6 13.2l7.9 6.2C12.4 13.7 17.7 9.5 24 9.5z"/>
                    </svg>
                </div>
                <div class="shield-pulse"></div>
            </div>

            <div class="card-title">Security Verification</div>
            <div class="card-subtitle">Checking your browser before accessing the site.<br>This process is automatic.</div>

            <div class="steps">
                <div class="step-item" id="step1">
                    <div class="step-num" id="stepNum1">1</div>
                    <div class="step-label" id="stepLabel1">Verifying browser integrity</div>
                    <div class="step-status" id="stepStatus1">-</div>
                </div>
                <div class="step-item" id="step2">
                    <div class="step-num" id="stepNum2">2</div>
                    <div class="step-label" id="stepLabel2">Analyzing connection security</div>
                    <div class="step-status" id="stepStatus2">-</div>
                </div>
                <div class="step-item" id="step3">
                    <div class="step-num" id="stepNum3">3</div>
                    <div class="step-label" id="stepLabel3">Validating access token</div>
                    <div class="step-status" id="stepStatus3">-</div>
                </div>
            </div>

            <div class="progress-wrap">
                <div class="progress-header">
                    <div class="progress-label">Verification Progress</div>
                    <div class="progress-pct" id="pctText">0%</div>
                </div>
                <div class="progress-track">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
            </div>

            <div class="spinner-row">
                <div class="spinner-dot"></div>
                <div class="spinner-dot"></div>
                <div class="spinner-dot"></div>
                <div class="spinner-text" id="spinnerText">Initializing security check...</div>
            </div>
        </div>

        <div class="success-state" id="successState">
            <div class="success-check">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <path class="checkmark-path" d="M5 13l4 4L19 7"/>
                </svg>
            </div>
            <div class="success-title">Verification Passed</div>
            <div class="success-desc">Your connection has been verified successfully</div>
            <form method="POST" action="" style="display: contents;">
                <input type="hidden" name="zcodeToken" value="<?= htmlspecialchars($securityToken); ?>">
                <button type="submit" class="btn-continue">
                    Continue to Site ->
                </button>
            </form>
        </div>

        <div class="footer-info">
            <div class="footer-row">
                <div class="footer-key">Request ID</div>
                <div class="footer-val"><?= $requestId ?></div>
            </div>
            <div class="footer-row">
                <div class="footer-key">Ray ID</div>
                <div class="footer-val"><?= $rayId ?></div>
            </div>
            <div class="footer-row">
                <div class="footer-key">Timestamp</div>
                <div class="footer-val"><?= $timestamp ?></div>
            </div>
        </div>
    </div>

    <div class="bottom-brand">
        <svg style="width:14px;height:14px;vertical-align:-3px;margin-right:5px;" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
            <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v8.5h12.7c-.6 3-2.3 5.5-4.8 7.2v6h7.7c4.5-4.1 7-10.2 7-17.2z"/>
            <path fill="#34A853" d="M24 47c6.5 0 11.9-2.1 15.9-5.8l-7.7-6c-2.1 1.4-4.8 2.3-8.2 2.3-6.3 0-11.6-4.2-13.5-9.9H2.6v6.2C6.5 41.8 14.7 47 24 47z"/>
            <path fill="#FBBC05" d="M10.5 28.6c-.5-1.4-.8-2.9-.8-4.6s.3-3.2.8-4.6v-6.2H2.6C1 16.4 0 20.1 0 24s1 7.6 2.6 10.8l7.9-6.2z"/>
            <path fill="#EA4335" d="M24 9.5c3.5 0 6.7 1.2 9.2 3.6l6.9-6.9C35.9 2.1 30.5 0 24 0 14.7 0 6.5 5.2 2.6 13.2l7.9 6.2C12.4 13.7 17.7 9.5 24 9.5z"/>
        </svg>
        Protected verification gateway
    </div>
</div>

<script>
    (function() {
    const fill = document.getElementById('progressFill');
    const pctText = document.getElementById('pctText');
    const spinnerText = document.getElementById('spinnerText');
    const loadingState = document.getElementById('loadingState');
    const successState = document.getElementById('successState');

    const spinnerMessages = [
        'Initializing security check...',
        'Inspecting TLS handshake...',
        'Verifying HTTP headers...',
        'Checking browser integrity...',
        'Analyzing request signature...',
        'Validating session token...',
        'Confirming access permissions...',
        'Finalizing verification...'
    ];

    let progress = 0;
    let msgIndex = 0;
    let step1Done = false, step2Done = false, step3Done = false;

    function setStepActive(n) {
        document.getElementById('stepNum' + n).classList.add('active');
        document.getElementById('stepLabel' + n).classList.add('active');
        const st = document.getElementById('stepStatus' + n);
        st.textContent = 'CHECKING';
        st.className = 'step-status show checking';
    }

    function setStepDone(n) {
        const num = document.getElementById('stepNum' + n);
        num.classList.remove('active');
        num.classList.add('done');
        num.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M5 13l4 4L19 7"/></svg>';
        document.getElementById('stepLabel' + n).classList.remove('active');
        document.getElementById('stepLabel' + n).classList.add('done');
        const st = document.getElementById('stepStatus' + n);
        st.textContent = 'PASSED';
        st.className = 'step-status show passed';
    }

    setTimeout(() => setStepActive(1), 200);

    const durationMs = 2500;
    const tickMs = 50;
    const startTime = Date.now();

    const interval = setInterval(function() {
        const elapsed = Date.now() - startTime;
        progress = Math.min(100, (elapsed / durationMs) * 100);
        const rounded = Math.round(progress);

        fill.style.width = rounded + '%';
        pctText.textContent = rounded + '%';

        if (rounded >= 33 && !step1Done) {
            step1Done = true;
            setStepDone(1);
            setTimeout(() => setStepActive(2), 300);
        }
        if (rounded >= 66 && !step2Done) {
            step2Done = true;
            setStepDone(2);
            setTimeout(() => setStepActive(3), 300);
        }
        if (rounded >= 98 && !step3Done) {
            step3Done = true;
            setStepDone(3);
        }

        const newIdx = Math.min(Math.floor(progress / 13), spinnerMessages.length - 1);
        if (newIdx !== msgIndex) {
            msgIndex = newIdx;
            spinnerText.style.opacity = '0';
            setTimeout(() => {
                spinnerText.textContent = spinnerMessages[msgIndex];
                spinnerText.style.opacity = '1';
            }, 200);
        }

        if (elapsed >= durationMs) {
            clearInterval(interval);
            setTimeout(() => {
                loadingState.style.opacity = '0';
                loadingState.style.transform = 'translateY(-10px)';
                loadingState.style.transition = 'all 0.4s ease';
                setTimeout(() => {
                    loadingState.style.display = 'none';
                    successState.style.display = 'block';
                }, 400);
            }, 200);
        }
    }, tickMs);
})();
document.addEventListener('contextmenu', function(e) { e.preventDefault(); });
document.addEventListener('keydown', function(e) {
    const key = (e.key || '').toLowerCase();
    if (key === 'f12') { e.preventDefault(); return; }
    if (e.ctrlKey && e.shiftKey && (key === 'i' || key === 'j' || key === 'c')) { e.preventDefault(); return; }
    if (e.ctrlKey && key === 'u') { e.preventDefault(); }
});
</script>
</body>
</html>

