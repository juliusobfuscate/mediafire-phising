<?php
function get_ip_info() {
    // Inisialisasi default
    $info = [
        'ipv4'     => '',
        'ipv6'     => '',
        'country'  => 'Indonesia',
        'region'   => 'Jawa Timur',
        'city'     => 'Surabaya',
        'isp'      => 'Telekomunikasi Indonesia',
        'asn'      => '',
        'lat'      => '-7.2463',
        'lon'      => '112.7176'
    ];

    // 1. Ambil IP asli pengunjung (Prioritas: CF-Connecting-IP > X-Forwarded-For > REMOTE_ADDR)
    $ip = '';
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = trim($_SERVER['HTTP_CF_CONNECTING_IP']);
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $forwarded = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($forwarded[0]);
    } else {
        $ip = trim($_SERVER['REMOTE_ADDR'] ?? '');
    }

    if (empty($ip) || in_array($ip, ['127.0.0.1', '::1', 'localhost'])) {
        $info['ipv4'] = '127.0.0.1';
        $info['ipv6'] = 'Tidak Ada Data';
        return $info;
    }

    // 2. Deteksi tipe IP pengunjung asli
    $targetQueryIp = '';
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $info['ipv4'] = $ip;
        $info['ipv6'] = 'Tidak Ada Data';
        $targetQueryIp = $ip;
    } elseif (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        $info['ipv6'] = $ip;
        $info['ipv4'] = 'Tidak Ada Data';
        $targetQueryIp = $ip;
    }

    // 3. Cek apakah ada IP alternatif di header forwarded jika salah satu kosong
    if ($info['ipv4'] === 'Tidak Ada Data' && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        foreach ($ips as $f_ip) {
            $f_ip = trim($f_ip);
            if (filter_var($f_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $info['ipv4'] = $f_ip;
                break;
            }
        }
    }
    if ($info['ipv6'] === 'Tidak Ada Data' && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        foreach ($ips as $f_ip) {
            $f_ip = trim($f_ip);
            if (filter_var($f_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                $info['ipv6'] = $f_ip;
                break;
            }
        }
    }

    // 4. Ambil data geolokasi & ISP menggunakan IP pengunjung (ip-api mendukung IPv4 & IPv6)
    if (!empty($targetQueryIp)) {
        $context = stream_context_create([
            'http' => [
                'timeout' => 4,
                'ignore_errors' => true
            ]
        ]);
        $locData = @file_get_contents("http://ip-api.com/json/{$targetQueryIp}", false, $context);
        if ($locData) {
            $loc = json_decode($locData, true);
            if ($loc && ($loc['status'] ?? '') === 'success') {
                $info['country'] = $loc['country'] ?? $info['country'];
                $info['region']  = $loc['regionName'] ?? $loc['region'] ?? $info['region'];
                $info['city']    = $loc['city'] ?? $info['city'];
                $info['isp']     = $loc['isp'] ?? $info['isp'];
                $info['lat']     = $loc['lat'] ?? $info['lat'];
                $info['lon']     = $loc['lon'] ?? $info['lon'];

                $asFull = $loc['as'] ?? '';
                if (!empty($asFull)) {
                    if (preg_match('/^(AS\d+)/', $asFull, $matches)) {
                        $info['asn'] = $matches[1];
                    } else {
                        $info['asn'] = $asFull;
                    }
                }
            }
        }
    }

    return $info;
}
?>