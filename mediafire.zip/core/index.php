<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>OWN TIRZZ23NESIA</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: black;
            font-family: 'Courier New', monospace;
            font-weight: bold;
            font-size: 24px;
            line-height: 1.5;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            cursor: pointer;
        }
        .spam {
            width: 100%;
            height: 100%;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
            text-align: center;
        }
        .spam span {
            display: inline-block;
            margin: 0 10px;
            animation: rgb 1s infinite;
        }
        @keyframes rgb {
            0% { color: red; }
            33% { color: lime; }
            66% { color: blue; }
            100% { color: red; }
        }
    </style>
</head>
<body onclick="window.location.href='https://wa.me/6285718662148'">
    <div class="spam" id="spamContainer"></div>

    <script>
        const container = document.getElementById('spamContainer');
        const totalSpam = 500;

        for (let i = 0; i < totalSpam; i++) {
            const span = document.createElement('span');
            span.textContent = 'TIRZZ23NESIA';
            container.appendChild(span);
        }
    </script>
</body>
</html>

